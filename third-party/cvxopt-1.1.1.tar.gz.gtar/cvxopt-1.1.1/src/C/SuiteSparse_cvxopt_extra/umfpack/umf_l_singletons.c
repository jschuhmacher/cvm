#define DLONG

#include "../../SuiteSparse/UMFPACK/Source/umf_singletons.c"
