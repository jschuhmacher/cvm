#define DLONG

#include "../../SuiteSparse/UMFPACK/Source/umf_blas3_update.c"
