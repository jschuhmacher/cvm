#define DINT
#include "../../SuiteSparse/UMFPACK/Source/umf_local_search.c"
