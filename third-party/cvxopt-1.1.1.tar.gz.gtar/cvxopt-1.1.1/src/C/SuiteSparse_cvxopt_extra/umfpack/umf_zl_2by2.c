#define ZLONG
 
#include "../../SuiteSparse/UMFPACK/Source/umf_2by2.c"
