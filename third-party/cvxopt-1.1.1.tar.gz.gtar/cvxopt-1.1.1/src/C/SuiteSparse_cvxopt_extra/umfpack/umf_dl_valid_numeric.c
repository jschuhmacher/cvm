#define DLONG

#include "../../SuiteSparse/UMFPACK/Source/umf_valid_numeric.c"
