#define ZLONG

#include "../../SuiteSparse/UMFPACK/Source/umfpack_numeric.c"
