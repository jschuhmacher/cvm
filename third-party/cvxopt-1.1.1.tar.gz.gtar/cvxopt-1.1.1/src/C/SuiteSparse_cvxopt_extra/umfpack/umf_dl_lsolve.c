#define DLONG

#include "../../SuiteSparse/UMFPACK/Source/umf_lsolve.c"
