#define DINT
#include "../../SuiteSparse/UMFPACK/Source/umfpack_numeric.c"
