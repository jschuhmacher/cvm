#define ZINT
#include "../../SuiteSparse/UMFPACK/Source/umfpack_qsymbolic.c"
