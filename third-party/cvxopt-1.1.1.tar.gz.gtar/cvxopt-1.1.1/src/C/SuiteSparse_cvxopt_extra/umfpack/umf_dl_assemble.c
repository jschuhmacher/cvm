#define DLONG

#include "../../SuiteSparse/UMFPACK/Source/umf_assemble.c"
