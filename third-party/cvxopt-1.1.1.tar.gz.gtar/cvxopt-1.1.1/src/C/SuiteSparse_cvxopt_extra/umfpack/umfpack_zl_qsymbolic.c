#define ZLONG

#include "../../SuiteSparse/UMFPACK/Source/umfpack_qsymbolic.c"
