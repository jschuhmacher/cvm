#define DLONG

#include "../../SuiteSparse/UMFPACK/Source/umfpack_numeric.c"
