#define ZLONG

#include "../../SuiteSparse/UMFPACK/Source/umf_extend_front.c"
