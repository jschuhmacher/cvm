#define DLONG

#include "../../SuiteSparse/AMD/Source/amd_1.c"
