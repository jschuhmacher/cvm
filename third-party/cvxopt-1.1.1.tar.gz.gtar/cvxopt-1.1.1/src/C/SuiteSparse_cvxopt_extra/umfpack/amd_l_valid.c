#define DLONG

#include "../../SuiteSparse/AMD/Source/amd_valid.c"
