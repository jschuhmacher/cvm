#define DLONG

#include "../../SuiteSparse/UMFPACK/Source/umf_row_search.c"
