#define ZLONG

#include "../../SuiteSparse/UMFPACK/Source/umf_garbage_collection.c"
